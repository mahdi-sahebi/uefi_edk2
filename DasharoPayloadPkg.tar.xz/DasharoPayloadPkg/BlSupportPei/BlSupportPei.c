/** @file
  This PEIM will parse bootloader information and report resource information into pei core.
  This file contains the main entrypoint of the PEIM.

Copyright (c) 2014 - 2019, Intel Corporation. All rights reserved.<BR>
SPDX-License-Identifier: BSD-2-Clause-Patent

**/
#include "BlSupportPei.h"
#include <Coreboot.h>
#include <IndustryStandard/UefiTcgPlatform.h>







/////////////////////////////////////////////////////

#include <stdarg.h> 

#include <Library/IoLib.h>
#include <Library/PrintLib.h>
#include <Library/BaseLib.h>
#include <Library/DebugLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/PcdLib.h>
// #include <Library/CpuLib.h>
// #include <Library/PeCoffGetEntryPointLib.h>
// #include <Library/PeCoffExtraActionLib.h>
#include <Library/DebugAgentLib.h>

#define mde_2__VGA_FB 0xB8000
#define mde_2__VGA_COLUMNS 80

char mde_2_g_buffer[80];

void mde_3_edkii_vga_write_at_offset(unsigned int line, unsigned int offset, const char *string)
{
	if (!string)
		return;

	unsigned short *p = (unsigned short *)mde_2__VGA_FB + (mde_2__VGA_COLUMNS * line) + offset;
	unsigned int i, len = AsciiStrLen(string);

	for (i = 0; i < (mde_2__VGA_COLUMNS - offset); i++) {
		if (i < len)
			p[i] = 0x0F00 | (unsigned char)string[i];
		else
			p[i] = 0x0F00;
	}
}


void mde_3_edkii_vga_print(unsigned int line, const char *string)
{
	mde_3_edkii_vga_write_at_offset(line, 0, string);
}

void mde_3_edkii_vga_sprintf(
  unsigned int row,
  const char* format,
  ...)
{
  VA_LIST  marker;
  
  VA_START (marker, format);
  AsciiVSPrint(mde_2_g_buffer, sizeof(mde_2_g_buffer), format, marker);
  VA_END (marker);
  
  mde_3_edkii_vga_print (row, mde_2_g_buffer);
}

void mde_3_edkii_vga_clear()
{
  mde_3_edkii_vga_print(0, "                                                                                                    ");
  mde_3_edkii_vga_print(1, "                                                                                                    ");
  mde_3_edkii_vga_print(2, "                                                                                                    ");
  mde_3_edkii_vga_print(3, "                                                                                                    ");
  mde_3_edkii_vga_print(4, "                                                                                                    ");
  mde_3_edkii_vga_print(5, "                                                                                                    ");
  mde_3_edkii_vga_print(6, "                                                                                                    ");
  mde_3_edkii_vga_print(7, "                                                                                                    ");
  mde_3_edkii_vga_print(8, "                                                                                                    ");
  mde_3_edkii_vga_print(9, "                                                                                                    ");
  mde_3_edkii_vga_print(10, "                                                                                                    ");
  mde_3_edkii_vga_print(11, "                                                                                                    ");
  mde_3_edkii_vga_print(12, "                                                                                                    ");
  mde_3_edkii_vga_print(13, "                                                                                                    ");
  mde_3_edkii_vga_print(14, "                                                                                                    ");
  mde_3_edkii_vga_print(15, "                                                                                                    ");
  mde_3_edkii_vga_print(16, "                                                                                                    ");
  mde_3_edkii_vga_print(17, "                                                                                                    ");
  mde_3_edkii_vga_print(18, "                                                                                                    ");
  mde_3_edkii_vga_print(19, "                                                                                                    ");
  mde_3_edkii_vga_print(20, "                                                                                                    ");
  mde_3_edkii_vga_print(21, "                                                                                                    ");
  mde_3_edkii_vga_print(22, "                                                                                                    ");
  mde_3_edkii_vga_print(23, "                                                                                                    ");
  mde_3_edkii_vga_print(24, "                                                                                                    ");
}

void mde_3_edkii_vga_hex_dump(const unsigned char *addr, unsigned int len, int start_row) 
{
    unsigned int i;
    
    for (i = 0; i < len; i += 16) {
        unsigned int j;
        int row = start_row + (i / 16);
        int offset_pos = 0;
        
        // Write offset character by character
        unsigned long ptr_val = (unsigned long)(addr + i);
        for (j = 28; j > 0; j -= 4) {
            char nibble = (ptr_val >> j) & 0x0F;
            char c = (nibble < 10) ? ('0' + nibble) : ('A' + nibble - 10);
            char buf[2] = {c, '\0'};
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, buf);
        }
        {
            char last_nibble = ptr_val & 0x0F;
            char c = (last_nibble < 10) ? ('0' + last_nibble) : ('A' + last_nibble - 10);
            char buf[2] = {c, '\0'};
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, buf);
        }
        mde_3_edkii_vga_write_at_offset(row, offset_pos++, ": ");
        
        // Write hex bytes
        for (j = 0; j < 16 && (i + j < len); j++) {
            unsigned char byte = addr[i + j];
            // Write high nibble
            char high = (byte >> 4) & 0x0F;
            char c1 = (high < 10) ? ('0' + high) : ('A' + high - 10);
            char buf1[2] = {c1, '\0'};
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, buf1);
            // Write low nibble
            char low = byte & 0x0F;
            char c2 = (low < 10) ? ('0' + low) : ('A' + low - 10);
            char buf2[2] = {c2, '\0'};
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, buf2);
            // Write space
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, " ");
        }
        
        // Pad remaining hex spaces
        for (; j < 16; j++) {
            mde_3_edkii_vga_write_at_offset(row, offset_pos++, "   ");
        }
        
        // Write ASCII representation
        mde_3_edkii_vga_write_at_offset(row, offset_pos++, "  ");
        
        for (j = 0; j < 16 && (i + j < len); j++) {
            unsigned char byte = addr[i + j];
            char c = (byte >= 0x20 && byte <= 0x7e) ? (char)byte : '.';
            char buf[2] = {c, '\0'};
            mde_3_edkii_vga_write_at_offset(row, offset_pos + j, buf);
        }
    }
}



/////////////////////////////////////////////////////






#define PEI_MEM_SIZE                      SIZE_64MB

#define LEGACY_8259_MASK_REGISTER_MASTER  0x21
#define LEGACY_8259_MASK_REGISTER_SLAVE   0xA1

EFI_MEMORY_TYPE_INFORMATION mDefaultMemoryTypeInformation[] = {
  { EfiACPIReclaimMemory,   FixedPcdGet32 (PcdMemoryTypeEfiACPIReclaimMemory) },
  { EfiACPIMemoryNVS,       FixedPcdGet32 (PcdMemoryTypeEfiACPIMemoryNVS) },
  { EfiReservedMemoryType,  FixedPcdGet32 (PcdMemoryTypeEfiReservedMemoryType) },
  { EfiRuntimeServicesData, FixedPcdGet32 (PcdMemoryTypeEfiRuntimeServicesData) },
  { EfiRuntimeServicesCode, FixedPcdGet32 (PcdMemoryTypeEfiRuntimeServicesCode) },
  { EfiMaxMemoryType,       0     }
};

EFI_PEI_PPI_DESCRIPTOR   mPpiBootMode[] = {
  {
    EFI_PEI_PPI_DESCRIPTOR_PPI | EFI_PEI_PPI_DESCRIPTOR_TERMINATE_LIST,
    &gEfiPeiMasterBootModePpiGuid,
    NULL
  }
};

EFI_PEI_GRAPHICS_DEVICE_INFO_HOB mDefaultGraphicsDeviceInfo = {
  MAX_UINT16, MAX_UINT16, MAX_UINT16, MAX_UINT16, MAX_UINT8,  MAX_UINT8
};

/**
  Create memory mapped io resource hob.

  @param  MmioBase    Base address of the memory mapped io range
  @param  MmioSize    Length of the memory mapped io range

**/
VOID
BuildMemoryMappedIoRangeHob (
  EFI_PHYSICAL_ADDRESS        MmioBase,
  UINT64                      MmioSize
  )
{
  BuildResourceDescriptorHob (
    EFI_RESOURCE_MEMORY_MAPPED_IO,
    (EFI_RESOURCE_ATTRIBUTE_PRESENT    |
    EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
    EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_TESTED),
    MmioBase,
    MmioSize
    );

  BuildMemoryAllocationHob (
    MmioBase,
    MmioSize,
    EfiMemoryMappedIO
    );
}

/**
  Check the integrity of firmware volume header

  @param[in]  FwVolHeader   A pointer to a firmware volume header

  @retval     TRUE          The firmware volume is consistent
  @retval     FALSE         The firmware volume has corrupted.

**/
STATIC
BOOLEAN
IsFvHeaderValid (
  IN EFI_FIRMWARE_VOLUME_HEADER    *FwVolHeader
  )
{
  UINT16 Checksum;

  // Skip nv storage fv
  if (CompareMem (&FwVolHeader->FileSystemGuid, &gEfiFirmwareFileSystem2Guid, sizeof(EFI_GUID)) != 0 ) {
    return FALSE;
  }

  if ( (FwVolHeader->Revision != EFI_FVH_REVISION)   ||
     (FwVolHeader->Signature != EFI_FVH_SIGNATURE) ||
     (FwVolHeader->FvLength == ((UINTN) -1))       ||
     ((FwVolHeader->HeaderLength & 0x01 ) !=0) )  {
    return FALSE;
  }

  Checksum = CalculateCheckSum16 ((UINT16 *) FwVolHeader, FwVolHeader->HeaderLength);
  if (Checksum != 0) {
    DEBUG (( DEBUG_ERROR,
              "ERROR - Invalid Firmware Volume Header Checksum, change 0x%04x to 0x%04x\r\n",
              FwVolHeader->Checksum,
              (UINT16)( Checksum + FwVolHeader->Checksum )));
    return TRUE; //FALSE; Need update UEFI build tool when patching entrypoin @start of fd.
  }

  return TRUE;
}

/**
  Install FvInfo PPI and create fv hobs for remained fvs

**/
VOID
PeiReportRemainedFvs (
  VOID
  )
{
  UINT8*  TempPtr;
  UINT8*  EndPtr;

  TempPtr = (UINT8* )(UINTN) PcdGet32 (PcdPayloadFdMemBase);
  EndPtr = (UINT8* )(UINTN) (PcdGet32 (PcdPayloadFdMemBase) + PcdGet32 (PcdPayloadFdMemSize));

  for (;TempPtr < EndPtr;) {
    if (IsFvHeaderValid ((EFI_FIRMWARE_VOLUME_HEADER* )TempPtr)) {
      if (TempPtr != (UINT8* )(UINTN) PcdGet32 (PcdPayloadFdMemBase))  {
        // Skip the PEI FV
        DEBUG((DEBUG_INFO, "Found one valid fv : 0x%lx.\n", TempPtr, ((EFI_FIRMWARE_VOLUME_HEADER* )TempPtr)->FvLength));

        PeiServicesInstallFvInfoPpi (
          NULL,
          (VOID *) (UINTN) TempPtr,
          (UINT32) (UINTN) ((EFI_FIRMWARE_VOLUME_HEADER* )TempPtr)->FvLength,
          NULL,
          NULL
          );
        BuildFvHob ((EFI_PHYSICAL_ADDRESS)(UINTN) TempPtr, ((EFI_FIRMWARE_VOLUME_HEADER* )TempPtr)->FvLength);
      }
    }
    TempPtr += ((EFI_FIRMWARE_VOLUME_HEADER* )TempPtr)->FvLength;
  }
}


/**
  Find the board related info from ACPI table

  @param  AcpiTableBase          ACPI table start address in memory
  @param  AcpiBoardInfo          Pointer to the acpi board info strucutre

  @retval RETURN_SUCCESS     Successfully find out all the required information.
  @retval RETURN_NOT_FOUND   Failed to find the required info.

**/
RETURN_STATUS
ParseAcpiInfo (
  IN   UINT64                                   AcpiTableBase,
  OUT  ACPI_BOARD_INFO                          *AcpiBoardInfo
  )
{
  EFI_ACPI_3_0_ROOT_SYSTEM_DESCRIPTION_POINTER  *Rsdp;
  EFI_ACPI_DESCRIPTION_HEADER                   *Rsdt;
  UINT32                                        *Entry32;
  UINTN                                         Entry32Num;
  EFI_ACPI_3_0_FIXED_ACPI_DESCRIPTION_TABLE     *Fadt;
  EFI_ACPI_DESCRIPTION_HEADER                   *Xsdt;
  UINT64                                        *Entry64;
  UINTN                                         Entry64Num;
  UINTN                                         Idx;
  UINT32                                        *Signature;
  EFI_ACPI_MEMORY_MAPPED_CONFIGURATION_BASE_ADDRESS_TABLE_HEADER *MmCfgHdr;
  EFI_ACPI_MEMORY_MAPPED_ENHANCED_CONFIGURATION_SPACE_BASE_ADDRESS_ALLOCATION_STRUCTURE *MmCfgBase;

  Rsdp = (EFI_ACPI_3_0_ROOT_SYSTEM_DESCRIPTION_POINTER *)(UINTN)AcpiTableBase;
  DEBUG ((DEBUG_INFO, "Rsdp at 0x%p\n", Rsdp));
  DEBUG ((DEBUG_INFO, "Rsdt at 0x%x, Xsdt at 0x%lx\n", Rsdp->RsdtAddress, Rsdp->XsdtAddress));

  //
  // Search Rsdt First
  //
  Fadt     = NULL;
  MmCfgHdr = NULL;
  Rsdt     = (EFI_ACPI_DESCRIPTION_HEADER *)(UINTN)(Rsdp->RsdtAddress);
  if (Rsdt != NULL) {
    Entry32  = (UINT32 *)(Rsdt + 1);
    Entry32Num = (Rsdt->Length - sizeof(EFI_ACPI_DESCRIPTION_HEADER)) >> 2;
    for (Idx = 0; Idx < Entry32Num; Idx++) {
      Signature = (UINT32 *)(UINTN)Entry32[Idx];
      if (*Signature == EFI_ACPI_3_0_FIXED_ACPI_DESCRIPTION_TABLE_SIGNATURE) {
        Fadt = (EFI_ACPI_3_0_FIXED_ACPI_DESCRIPTION_TABLE *)Signature;
        DEBUG ((DEBUG_INFO, "Found Fadt in Rsdt\n"));
      }

      if (*Signature == EFI_ACPI_5_0_PCI_EXPRESS_MEMORY_MAPPED_CONFIGURATION_SPACE_BASE_ADDRESS_DESCRIPTION_TABLE_SIGNATURE) {
        MmCfgHdr = (EFI_ACPI_MEMORY_MAPPED_CONFIGURATION_BASE_ADDRESS_TABLE_HEADER *)Signature;
        DEBUG ((DEBUG_INFO, "Found MM config address in Rsdt\n"));
      }

      if ((Fadt != NULL) && (MmCfgHdr != NULL)) {
        goto Done;
      }
    }
  }

  //
  // Search Xsdt Second
  //
  Xsdt     = (EFI_ACPI_DESCRIPTION_HEADER *)(UINTN)(Rsdp->XsdtAddress);
  if (Xsdt != NULL) {
    Entry64  = (UINT64 *)(Xsdt + 1);
    Entry64Num = (Xsdt->Length - sizeof(EFI_ACPI_DESCRIPTION_HEADER)) >> 3;
    for (Idx = 0; Idx < Entry64Num; Idx++) {
      Signature = (UINT32 *)(UINTN)Entry64[Idx];
      if (*Signature == EFI_ACPI_3_0_FIXED_ACPI_DESCRIPTION_TABLE_SIGNATURE) {
        Fadt = (EFI_ACPI_3_0_FIXED_ACPI_DESCRIPTION_TABLE *)Signature;
        DEBUG ((DEBUG_INFO, "Found Fadt in Xsdt\n"));
      }

      if (*Signature == EFI_ACPI_5_0_PCI_EXPRESS_MEMORY_MAPPED_CONFIGURATION_SPACE_BASE_ADDRESS_DESCRIPTION_TABLE_SIGNATURE) {
        MmCfgHdr = (EFI_ACPI_MEMORY_MAPPED_CONFIGURATION_BASE_ADDRESS_TABLE_HEADER *)Signature;
        DEBUG ((DEBUG_INFO, "Found MM config address in Xsdt\n"));
      }

      if ((Fadt != NULL) && (MmCfgHdr != NULL)) {
        goto Done;
      }
    }
  }

  if (Fadt == NULL) {
    return RETURN_NOT_FOUND;
  }

Done:

  AcpiBoardInfo->PmCtrlRegBase   = Fadt->Pm1aCntBlk;
  AcpiBoardInfo->PmTimerRegBase  = Fadt->PmTmrBlk;
  AcpiBoardInfo->ResetRegAddress = Fadt->ResetReg.Address;
  AcpiBoardInfo->ResetValue      = Fadt->ResetValue;
  AcpiBoardInfo->PmEvtBase       = Fadt->Pm1aEvtBlk;
  AcpiBoardInfo->PmGpeEnBase     = Fadt->Gpe0Blk + Fadt->Gpe0BlkLen / 2;

  if (MmCfgHdr != NULL) {
    MmCfgBase = (EFI_ACPI_MEMORY_MAPPED_ENHANCED_CONFIGURATION_SPACE_BASE_ADDRESS_ALLOCATION_STRUCTURE *)((UINT8*) MmCfgHdr + sizeof (*MmCfgHdr));
    AcpiBoardInfo->PcieBaseAddress = MmCfgBase->BaseAddress;
    AcpiBoardInfo->PcieBaseSize = (MmCfgBase->EndBusNumber + 1 - MmCfgBase->StartBusNumber) * 4096 * 32 * 8;
  } else {
    AcpiBoardInfo->PcieBaseAddress = 0;
    AcpiBoardInfo->PcieBaseSize = 0;
  }
  DEBUG ((DEBUG_INFO, "PmCtrl  Reg 0x%lx\n",  AcpiBoardInfo->PmCtrlRegBase));
  DEBUG ((DEBUG_INFO, "PmTimer Reg 0x%lx\n",  AcpiBoardInfo->PmTimerRegBase));
  DEBUG ((DEBUG_INFO, "Reset   Reg 0x%lx\n",  AcpiBoardInfo->ResetRegAddress));
  DEBUG ((DEBUG_INFO, "Reset   Value 0x%x\n", AcpiBoardInfo->ResetValue));
  DEBUG ((DEBUG_INFO, "PmEvt   Reg 0x%lx\n",  AcpiBoardInfo->PmEvtBase));
  DEBUG ((DEBUG_INFO, "PmGpeEn Reg 0x%lx\n",  AcpiBoardInfo->PmGpeEnBase));
  DEBUG ((DEBUG_INFO, "PcieBaseAddr 0x%lx\n", AcpiBoardInfo->PcieBaseAddress));
  DEBUG ((DEBUG_INFO, "PcieBaseSize 0x%lx\n", AcpiBoardInfo->PcieBaseSize));

  //
  // Verify values for proper operation
  //
  ASSERT(Fadt->Pm1aCntBlk != 0);
  ASSERT(Fadt->PmTmrBlk != 0);
  ASSERT(Fadt->ResetReg.Address != 0);
  ASSERT(Fadt->Pm1aEvtBlk != 0);
  ASSERT(Fadt->Gpe0Blk != 0);

  DEBUG_CODE_BEGIN ();
    BOOLEAN    SciEnabled;

    //
    // Check the consistency of SCI enabling
    //

    //
    // Get SCI_EN value
    //
   if (Fadt->Pm1CntLen == 4) {
      SciEnabled = (IoRead32 (Fadt->Pm1aCntBlk) & BIT0)? TRUE : FALSE;
    } else {
      //
      // if (Pm1CntLen == 2), use 16 bit IO read;
      // if (Pm1CntLen != 2 && Pm1CntLen != 4), use 16 bit IO read as a fallback
      //
      SciEnabled = (IoRead16 (Fadt->Pm1aCntBlk) & BIT0)? TRUE : FALSE;
    }

    if (!(Fadt->Flags & EFI_ACPI_5_0_HW_REDUCED_ACPI) &&
        (Fadt->SmiCmd == 0) &&
       !SciEnabled) {
      //
      // The ACPI enabling status is inconsistent: SCI is not enabled but ACPI
      // table does not provide a means to enable it through FADT->SmiCmd
      //
      DEBUG ((DEBUG_ERROR, "ERROR: The ACPI enabling status is inconsistent: SCI is not"
        " enabled but the ACPI table does not provide a means to enable it through FADT->SmiCmd."
        " This may cause issues in OS.\n"));
    }
  DEBUG_CODE_END ();

  return RETURN_SUCCESS;
}

EFI_STATUS
MemInfoCallback (
  IN MEMROY_MAP_ENTRY             *MemoryMapEntry,
  IN VOID                         *Params
  )
{
  EFI_PHYSICAL_ADDRESS    *UsableLowMemTop;
  UINTN                   Attribute;
  EFI_PHYSICAL_ADDRESS    Base;
  EFI_RESOURCE_TYPE       Type;
  UINT64                  Size;
  UINT8                   Flag;

  Attribute = EFI_RESOURCE_ATTRIBUTE_PRESENT |
             EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
             EFI_RESOURCE_ATTRIBUTE_TESTED |
             EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
             EFI_RESOURCE_ATTRIBUTE_WRITE_COMBINEABLE |
             EFI_RESOURCE_ATTRIBUTE_WRITE_THROUGH_CACHEABLE |
             EFI_RESOURCE_ATTRIBUTE_WRITE_BACK_CACHEABLE;

  UsableLowMemTop = (EFI_PHYSICAL_ADDRESS *)Params;
  Type            = MemoryMapEntry->Type;
  Base            = MemoryMapEntry->Base;
  Size            = MemoryMapEntry->Size;
  Flag            = MemoryMapEntry->Flag;

  if ((Base  < BASE_1MB) && ((Base + Size) > BASE_1MB)) {
    Size -= (BASE_1MB - Base);
    Base  = BASE_1MB;
  }

  if (Base >= BASE_1MB) {
    if (!(Flag & EFI_RESOURCE_ATTRIBUTE_PRESENT)) {
      BuildResourceDescriptorHob (
        Type,
        0,
        (EFI_PHYSICAL_ADDRESS)Base,
        Size
        );
    } else if (Type == EFI_RESOURCE_SYSTEM_MEMORY) {
      if (Base < BASE_4GB) {
        // Track the highest low-RAM region top regardless of individual size.
        // Skipping regions < PEI_MEM_SIZE caused UsableLowMemTop=0 on Xeon SP
        // when low RAM is fragmented into many sub-64MB pieces, leading to
        // PeiMemBase underflow (0 - 64MB = 0xFFFFFFFFFC000000) and PeiCore crash.
        if ((Base + Size) > *UsableLowMemTop) {
          *UsableLowMemTop = Base + Size;
        }
      } else {
        Attribute &= ~EFI_RESOURCE_ATTRIBUTE_TESTED;
      }
      BuildResourceDescriptorHob (
        EFI_RESOURCE_SYSTEM_MEMORY,
        Attribute,
        (EFI_PHYSICAL_ADDRESS)Base,
        Size
        );
    } else if (Type == EFI_RESOURCE_MEMORY_RESERVED) {
      BuildResourceDescriptorHob (
        EFI_RESOURCE_MEMORY_RESERVED,
        Attribute,
        (EFI_PHYSICAL_ADDRESS)Base,
        Size
        );
      BuildMemoryAllocationHob (
        (EFI_PHYSICAL_ADDRESS)Base,
        Size,
        EfiACPIReclaimMemory
        );
    } else if (Type == EFI_RESOURCE_MEMORY_MAPPED_IO) {
      BuildMemoryMappedIoRangeHob((EFI_PHYSICAL_ADDRESS)Base, Size);
    } else if (Type == EFI_RESOURCE_FIRMWARE_DEVICE) {
      BuildResourceDescriptorHob (
          EFI_RESOURCE_FIRMWARE_DEVICE,
          (EFI_RESOURCE_ATTRIBUTE_PRESENT    |
          EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
          EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
          EFI_RESOURCE_ATTRIBUTE_TESTED),
          (EFI_PHYSICAL_ADDRESS)Base,
          Size
          );
      BuildMemoryAllocationHob (
        (EFI_PHYSICAL_ADDRESS)Base,
        Size,
        EfiACPIMemoryNVS
        );
    }
  }

  return EFI_SUCCESS;
}

/**
  Check the integrity of firmware volume header.

  @retval  EFI_SUCCESS   - The firmware volume is consistent
  @retval  EFI_NOT_FOUND - The firmware volume has been corrupted.

**/
EFI_STATUS
ValidateFvHeader (
  SMMSTORE_INFO *SmmStoreInfo
  )
{
  UINT16                      Checksum;
  EFI_FIRMWARE_VOLUME_HEADER  *FwVolHeader;
  VARIABLE_STORE_HEADER       *VariableStoreHeader;
  UINTN                       VariableStoreLength;
  UINTN                       FvLength;
  UINT32                      NvStorageSize;
  UINT32                      NvVariableSize;
  UINT32                      FtwWorkingSize;
  UINT32                      FtwSpareSize;


  NvStorageSize = SmmStoreInfo->NumBlocks * SmmStoreInfo->BlockSize;
  FtwSpareSize   = (SmmStoreInfo->NumBlocks / 2) * SmmStoreInfo->BlockSize;
  FtwWorkingSize = SmmStoreInfo->BlockSize;
  NvVariableSize = NvStorageSize - FtwSpareSize - FtwWorkingSize;

  FwVolHeader        = (EFI_FIRMWARE_VOLUME_HEADER *)(UINTN)SmmStoreInfo->MmioAddress;
  if (!FwVolHeader) {
    return EFI_OUT_OF_RESOURCES;
  }


  FvLength = FtwSpareSize + FtwWorkingSize + NvVariableSize;

  //
  // Verify the header revision, header signature, length
  // Length of FvBlock cannot be 2**64-1
  // HeaderLength cannot be an odd number
  //
  if (  (FwVolHeader->Revision  != EFI_FVH_REVISION)
     || (FwVolHeader->Signature != EFI_FVH_SIGNATURE)
     || (FwVolHeader->FvLength  != FvLength)
        )
  {
    DEBUG ((
      DEBUG_INFO,
      "%a: No Firmware Volume header present\n",
      __FUNCTION__
      ));
    return EFI_NOT_FOUND;
  }

  // Check the Firmware Volume Guid
  if ( CompareGuid (&FwVolHeader->FileSystemGuid, &gEfiSystemNvDataFvGuid) == FALSE ) {
    DEBUG ((
      DEBUG_INFO,
      "%a: Firmware Volume Guid non-compatible\n",
      __FUNCTION__
      ));
    return EFI_NOT_FOUND;
  }

  // Verify the header checksum
  Checksum = CalculateSum16 ((UINT16 *)FwVolHeader, FwVolHeader->HeaderLength);
  if (Checksum != 0) {
    DEBUG ((
      DEBUG_INFO,
      "%a: FV checksum is invalid (Checksum:0x%X)\n",
      __FUNCTION__,
      Checksum
      ));
    return EFI_NOT_FOUND;
  }

  VariableStoreHeader = (VARIABLE_STORE_HEADER *)(UINTN)(SmmStoreInfo->MmioAddress + FwVolHeader->HeaderLength);

  // Check the Variable Store Guid
  if (!CompareGuid (&VariableStoreHeader->Signature, &gEfiVariableGuid) &&
      !CompareGuid (&VariableStoreHeader->Signature, &gEfiAuthenticatedVariableGuid))
  {
    DEBUG ((
      DEBUG_INFO,
      "%a: Variable Store Guid non-compatible\n",
      __FUNCTION__
      ));
    return EFI_NOT_FOUND;
  }

  VariableStoreLength = NvVariableSize - FwVolHeader->HeaderLength;
  if (VariableStoreHeader->Size != VariableStoreLength) {
    DEBUG ((
      DEBUG_INFO,
      "%a: Variable Store Length does not match\n",
      __FUNCTION__
      ));
    return EFI_NOT_FOUND;
  }

  return EFI_SUCCESS;
}

STATIC
EFI_STATUS
ParseAndPublishTPM1Log (
  CONST struct tcpa_spec_entry  *SpecEntry,
  UINTN                         Size
)
{
  UINT8                  ZeroBlock[sizeof (struct tcpa_spec_entry)];
  struct tcpa_log_entry  *Entry;
  EFI_PHYSICAL_ADDRESS   Start;
  EFI_PHYSICAL_ADDRESS   Current;
  UINTN                  EntrySize;

  // This must hold to avoid integer overflow below.
  ASSERT (Size >= sizeof (*Entry));

  ZeroMem (ZeroBlock, sizeof (ZeroBlock));

  Start = (EFI_PHYSICAL_ADDRESS)(UINTN) SpecEntry;
  Current = Start;
  while (Current - Start < Size - sizeof (*Entry) &&
         CompareMem ((VOID *)(UINTN) Current, (VOID *) ZeroBlock, sizeof (ZeroBlock)) != 0) {
    Entry = (VOID *)(UINTN) Current;
    EntrySize = sizeof (*Entry) + Entry->event_data_size;

    BuildGuidDataHob (&gTcgEventEntryHobGuid, Entry, EntrySize);
    Current += EntrySize;
  }

  return EFI_SUCCESS;
}

STATIC
EFI_STATUS
ParseAndPublishTPM2Log (
  CONST struct tcg_efi_spec_id_event  *SpecEntry,
  UINTN                               Size
)
{
  UINT8                         ZeroBlock[sizeof (struct tcg_pcr_event2_header)];
  struct tcg_pcr_event2_header  *Header;
  EFI_PHYSICAL_ADDRESS          Start;
  EFI_PHYSICAL_ADDRESS          Current;
  UINTN                         EntrySize;
  UINTN                         DigestsSize;
  UINTN                         Idx;

  // This must hold to avoid integer overflow below.
  ASSERT (Size >= sizeof (*Header));

  ZeroMem (ZeroBlock, sizeof (ZeroBlock));

  DigestsSize = 0;
  for (Idx = 0; Idx < SpecEntry->num_of_algorithms; ++Idx) {
    DigestsSize += sizeof (UINT16) + SpecEntry->digest_sizes[Idx].digest_size;
  }

  Start = (EFI_PHYSICAL_ADDRESS)(UINTN) SpecEntry;

  // Not adding Spec ID Event for TPM2 because Tcg2Dxe adds one, coreboot's
  // event would have to be modified to be suitable due to the list of
  // algorithms there.
  Current = Start + sizeof (struct tcpa_log_entry) + SpecEntry->event_size;

  while (Current - Start < Size - sizeof (*Header) &&
         CompareMem ((VOID *)(UINTN) Current, (VOID *) ZeroBlock, sizeof (ZeroBlock)) != 0) {
    Header = (VOID *)(UINTN) Current;
    EntrySize = sizeof (*Header) + DigestsSize;

    // Event data size field and data itself.
    EntrySize += sizeof (UINT32) + *(CONST UINT32 *)(UINTN) (Current + EntrySize);

    BuildGuidDataHob (&gTcgEvent2EntryHobGuid, Header, EntrySize);
    Current += EntrySize;
  }

  return EFI_SUCCESS;
}

STATIC
EFI_STATUS
ParseAndPublishTPMLog (
  VOID
)
{
  RETURN_STATUS  Status;
  VOID           *LogBase;
  UINTN          LogSize;

  const struct tcpa_spec_entry        *Tcg1Entry;
  const struct tcg_efi_spec_id_event  *Tcg2Entry;

  Status = ParseTPMLog (&LogBase, &LogSize);
  if (EFI_ERROR (Status)) {
    DEBUG ((
      DEBUG_INFO,
      "%a: Not publishing coreboot's TPM log entries because: %r.\n",
      __FUNCTION__, Status
      ));
    return Status;
  }

  Tcg1Entry = LogBase;
  if (AsciiStrCmp((CONST CHAR8 *)Tcg1Entry->signature, TCPA_SPEC_ID_EVENT_SIGNATURE) == 0) {
    if (Tcg1Entry->spec_version_major == 1 &&
        Tcg1Entry->spec_version_minor == 2 &&
        Tcg1Entry->spec_errata >= 1 &&
        Tcg1Entry->entry.event_type == EV_NO_ACTION) {
      return ParseAndPublishTPM1Log (Tcg1Entry, LogSize);
    }

    DEBUG ((DEBUG_WARN, "%a: Unknown TPM1.2 log specification.\n", __FUNCTION__));
    return EFI_UNSUPPORTED;
  }

  Tcg2Entry = LogBase;
  if (AsciiStrCmp((CONST CHAR8 *)Tcg1Entry->signature, TCG_EFI_SPEC_ID_EVENT_SIGNATURE) == 0) {
    if (Tcg2Entry->spec_version_major == 2 &&
        Tcg2Entry->spec_version_minor == 0 &&
        Tcg2Entry->event_type == EV_NO_ACTION) {
      return ParseAndPublishTPM2Log (Tcg2Entry, LogSize);
    }

    DEBUG ((DEBUG_WARN, "%a: Unknown TPM2 log specification.\n", __FUNCTION__));
    return EFI_UNSUPPORTED;
  }

  DEBUG ((DEBUG_WARN,
          "%a: Unknown TPM log specification %.*s.\n",
          __FUNCTION__, (int)sizeof(Tcg2Entry->signature), (CONST CHAR8 *)Tcg2Entry->signature));
  return EFI_UNSUPPORTED;
}

/**
  This is the entrypoint of PEIM

  @param  FileHandle  Handle of the file being invoked.
  @param  PeiServices Describes the list of possible PEI Services.

  @retval EFI_SUCCESS if it completed successfully.
**/
EFI_STATUS
EFIAPI
BlPeiEntryPoint (
  IN       EFI_PEI_FILE_HANDLE     FileHandle,
  IN CONST EFI_PEI_SERVICES        **PeiServices
  )
{
  EFI_STATUS                       Status;
  EFI_PHYSICAL_ADDRESS             UsableLowMemTop = 0;
  EFI_PHYSICAL_ADDRESS             PeiMemBase = 0;
  UINT32                           RegEax;
  UINT8                            PhysicalAddressBits;
  SYSTEM_TABLE_INFO                SysTableInfo;
  SYSTEM_TABLE_INFO                *NewSysTableInfo;
  ACPI_BOARD_INFO                  AcpiBoardInfo;
  ACPI_BOARD_INFO                  *NewAcpiBoardInfo;
  SMMSTORE_INFO                    SMMSTOREInfo;
  SMMSTORE_INFO                    *NewSMMSTOREInfo;
  TCG_PHYSICAL_PRESENCE_INFO       PhysicalPresenceInfo;
  TCG_PHYSICAL_PRESENCE_INFO       *NewPhysicalPresenceInfo;
  EFI_PEI_GRAPHICS_INFO_HOB        GfxInfo;
  EFI_PEI_GRAPHICS_INFO_HOB        *NewGfxInfo;
  EFI_PEI_GRAPHICS_DEVICE_INFO_HOB GfxDeviceInfo;
  EFI_PEI_GRAPHICS_DEVICE_INFO_HOB *NewGfxDeviceInfo;
  FIRMWARE_SEC_PERFORMANCE         Performance;


  mde_3_edkii_vga_clear();
  
  mde_3_edkii_vga_sprintf(0, "BLSa-%x,%x",
    FileHandle,
    PeiServices
  );


  // Report lower 640KB of RAM.
  // Mark memory as reserved to keep coreboot header in place.
  //
  BuildResourceDescriptorHob (
    EFI_RESOURCE_MEMORY_RESERVED,
    (
    EFI_RESOURCE_ATTRIBUTE_PRESENT |
    EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
    EFI_RESOURCE_ATTRIBUTE_TESTED |
    EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_COMBINEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_THROUGH_CACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_BACK_CACHEABLE
    ),
    (EFI_PHYSICAL_ADDRESS)(0),
    (UINT64)(0x1000)
    );
  
  mde_3_edkii_vga_sprintf(0, "BLSb-%x,%x",
    FileHandle,
    PeiServices
  );

  BuildResourceDescriptorHob (
    EFI_RESOURCE_SYSTEM_MEMORY,
    (
    EFI_RESOURCE_ATTRIBUTE_PRESENT |
    EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
    EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_COMBINEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_THROUGH_CACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_BACK_CACHEABLE
    ),
    (EFI_PHYSICAL_ADDRESS)(0x1000),
    (UINT64)(0x9F000)
    );

  mde_3_edkii_vga_sprintf(0, "BLSc-%x,%x",
    FileHandle,
    PeiServices
  );

  BuildResourceDescriptorHob (
    EFI_RESOURCE_MEMORY_RESERVED,
    (
    EFI_RESOURCE_ATTRIBUTE_PRESENT |
    EFI_RESOURCE_ATTRIBUTE_INITIALIZED |
    EFI_RESOURCE_ATTRIBUTE_TESTED |
    EFI_RESOURCE_ATTRIBUTE_UNCACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_COMBINEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_THROUGH_CACHEABLE |
    EFI_RESOURCE_ATTRIBUTE_WRITE_BACK_CACHEABLE
    ),
    (EFI_PHYSICAL_ADDRESS)(0xA0000),
    (UINT64)(0x60000)
    );

  mde_3_edkii_vga_sprintf(0, "BLSd-%x,%x",
    FileHandle,
    PeiServices
  );

  //
  // Parse memory info
  //
  Status = ParseMemoryInfo (MemInfoCallback, &UsableLowMemTop);
  

  // if (EFI_ERROR(Status)) {
  //   return Status;
  // }

  //
  // Install memory
  //
  // ASSERT (UsableLowMemTop >= BASE_1MB + PEI_MEM_SIZE);
  PeiMemBase = (UsableLowMemTop - PEI_MEM_SIZE) & (~(BASE_64KB - 1));
  // DEBUG ((DEBUG_INFO, "UsableLowMemTop 0x%lx\n", UsableLowMemTop));
  // DEBUG ((DEBUG_INFO, "PeiMemBase: 0x%lx.\n", PeiMemBase));
  // DEBUG ((DEBUG_INFO, "PeiMemSize: 0x%lx.\n", PEI_MEM_SIZE));

  mde_3_edkii_vga_sprintf(0, "BLSe-%x,%x,%x,%x,%x",
    FileHandle,
    PeiServices,
    Status,
    UsableLowMemTop,
    PeiMemBase
  );

  Status = PeiServicesInstallPeiMemory (PeiMemBase, PEI_MEM_SIZE);
  
  mde_3_edkii_vga_sprintf(1, "BLSf-%x,%x,%x-%x,%x",
    FileHandle,
    PeiServices,
    Status,
    UsableLowMemTop,
    PeiMemBase
  );
  // ASSERT_EFI_ERROR (Status);

  //
  // Create Memory Type Information HOB
  //
  BuildGuidDataHob (
    &gEfiMemoryTypeInformationGuid,
    mDefaultMemoryTypeInformation,
    sizeof(mDefaultMemoryTypeInformation)
    );

  mde_3_edkii_vga_sprintf(1, "a-%x,%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation)
  );

  //
  // Create Fv hob
  //
  PeiReportRemainedFvs ();

  mde_3_edkii_vga_sprintf(1, "b-%x,%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation)
  );


  BuildMemoryAllocationHob (
    PcdGet32 (PcdPayloadFdMemBase),
    PcdGet32 (PcdPayloadFdMemSize),
    EfiBootServicesData
    );

  mde_3_edkii_vga_sprintf(1, "c-%x,%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation)
  );

  //
  // Build CPU memory space and IO space hob
  //
  AsmCpuid (0x80000000, &RegEax, NULL, NULL, NULL);
  
  mde_3_edkii_vga_sprintf(1, "d-%x,%x,%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation),
    RegEax
  );

  if (RegEax >= 0x80000008) {
    AsmCpuid (0x80000008, &RegEax, NULL, NULL, NULL);
    PhysicalAddressBits = (UINT8) RegEax;
  } else {
    PhysicalAddressBits  = 36;
  }

  mde_3_edkii_vga_sprintf(1, "e-%x,%x,%x-%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation),
    RegEax,
    PhysicalAddressBits
  );

  //
  // Create a CPU hand-off information
  //
  BuildCpuHob (PhysicalAddressBits, 16);

  mde_3_edkii_vga_sprintf(1, "f-%x,%x,%x-%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation),
    RegEax,
    PhysicalAddressBits
  );

  //
  // Report Local APIC range
  //
  BuildMemoryMappedIoRangeHob (0xFEC80000, SIZE_512KB);

  mde_3_edkii_vga_sprintf(1, "g-%x,%x,%x-%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation),
    RegEax,
    PhysicalAddressBits
  );

  //
  // Boot mode
  //
  Status = PeiServicesSetBootMode (BOOT_WITH_FULL_CONFIGURATION);
  
  mde_3_edkii_vga_sprintf(1, "h-%x,%x,%x-%x,%x",
    gEfiMemoryTypeInformationGuid,
    sizeof(mDefaultMemoryTypeInformation),
    RegEax,
    PhysicalAddressBits,
    Status
  );
  // ASSERT_EFI_ERROR (Status);

  Status = PeiServicesInstallPpi (mPpiBootMode);
  
  mde_3_edkii_vga_sprintf(2, "a-%x",
    Status
  );
  // ASSERT_EFI_ERROR (Status);

  //
  // Create guid hob for frame buffer information
  //
  Status = ParseGfxInfo (&GfxInfo);
  
  mde_3_edkii_vga_sprintf(2, "b-%x-%x-%x-%x",
    Status,
    GfxInfo.FrameBufferBase,
    GfxInfo.FrameBufferSize,
    GfxInfo.GraphicsMode
  );

  if (!EFI_ERROR (Status)) {
    NewGfxInfo = BuildGuidHob (&gEfiGraphicsInfoHobGuid, sizeof (GfxInfo));
    ASSERT (NewGfxInfo != NULL);
    CopyMem (NewGfxInfo, &GfxInfo, sizeof (GfxInfo));
    DEBUG ((DEBUG_INFO, "Created graphics info hob\n"));
  }


  Status = ParseGfxDeviceInfo (&GfxDeviceInfo);
  if (!EFI_ERROR (Status)) {
    NewGfxDeviceInfo = BuildGuidHob (&gEfiGraphicsDeviceInfoHobGuid, sizeof (GfxDeviceInfo));
    
    mde_3_edkii_vga_sprintf(3, "a-%x-%x-%x-%x,-%x-%x-%x-%x-%x",
      gEfiGraphicsDeviceInfoHobGuid.Data1,
      gEfiGraphicsDeviceInfoHobGuid.Data2,
      gEfiGraphicsDeviceInfoHobGuid.Data3,
      gEfiGraphicsDeviceInfoHobGuid.Data4,
      NewGfxDeviceInfo->BarIndex,
      NewGfxDeviceInfo->DeviceId,
      NewGfxDeviceInfo->RevisionId,
      NewGfxDeviceInfo->SubsystemId,
      NewGfxDeviceInfo->VendorId
    );
    
    // ASSERT (NewGfxDeviceInfo != NULL);
    CopyMem (NewGfxDeviceInfo, &GfxDeviceInfo, sizeof (GfxDeviceInfo));
    
    mde_3_edkii_vga_sprintf(3, "b-%x-%x-%x-%x,-%x-%x-%x-%x-%x",
      gEfiGraphicsDeviceInfoHobGuid.Data1,
      gEfiGraphicsDeviceInfoHobGuid.Data2,
      gEfiGraphicsDeviceInfoHobGuid.Data3,
      gEfiGraphicsDeviceInfoHobGuid.Data4,
      NewGfxDeviceInfo->BarIndex,
      NewGfxDeviceInfo->DeviceId,
      NewGfxDeviceInfo->RevisionId,
      NewGfxDeviceInfo->SubsystemId,
      NewGfxDeviceInfo->VendorId
    );
    DEBUG ((DEBUG_INFO, "Created graphics device info hob\n"));
  }

  //
  // Create guid hob for SMMSTORE
  //
  Status = ParseSMMSTOREInfo (&SMMSTOREInfo);

  mde_3_edkii_vga_sprintf(4, "a-%x-%x-%x-%x-%x-%x-%x",
    Status,
    SMMSTOREInfo.ApmCmd,
    SMMSTOREInfo.BlockSize,
    SMMSTOREInfo.ComBuffer,
    SMMSTOREInfo.ComBufferSize,
    SMMSTOREInfo.MmioAddress,
    SMMSTOREInfo.NumBlocks
  );
  
  if (!EFI_ERROR (Status)) {
    NewSMMSTOREInfo = BuildGuidHob (&gEfiSmmStoreInfoHobGuid, sizeof (SMMSTOREInfo));
    
    mde_3_edkii_vga_sprintf(5, "a-%x-%x,%x-%x-%x-%x-%x-%x",
      gEfiSmmStoreInfoHobGuid.Data1,
      gEfiSmmStoreInfoHobGuid.Data2,
      NewSMMSTOREInfo->ApmCmd,
      NewSMMSTOREInfo->BlockSize,
      NewSMMSTOREInfo->ComBuffer,
      NewSMMSTOREInfo->ComBufferSize,
      NewSMMSTOREInfo->MmioAddress,
      NewSMMSTOREInfo->NumBlocks
    );
    
    // ASSERT (NewSMMSTOREInfo != NULL);
    CopyMem (NewSMMSTOREInfo, &SMMSTOREInfo, sizeof (SMMSTOREInfo));
    
    mde_3_edkii_vga_sprintf(5, "b-%x-%x,%x-%x-%x-%x-%x-%x",
      gEfiSmmStoreInfoHobGuid.Data1,
      gEfiSmmStoreInfoHobGuid.Data2,
      NewSMMSTOREInfo->ApmCmd,
      NewSMMSTOREInfo->BlockSize,
      NewSMMSTOREInfo->ComBuffer,
      NewSMMSTOREInfo->ComBufferSize,
      NewSMMSTOREInfo->MmioAddress,
      NewSMMSTOREInfo->NumBlocks
    );
    // DEBUG ((DEBUG_INFO, "Created SMMSTORE info hob\n"));

    Status = ValidateFvHeader (&SMMSTOREInfo);
    
    mde_3_edkii_vga_sprintf(6, "a-%x",
      Status
    );

    //
    // gEdkiiFaultTolerantWriteGuid HOB doesn't exist if both working and spare
    // parts of the variable store are invalid, this is when we need to
    // initialize it with defaults.
    //
    if (EFI_ERROR (Status) && GetFirstGuidHob (&gEdkiiFaultTolerantWriteGuid) == NULL) {
      
      mde_3_edkii_vga_sprintf(6, "b-%x",
        Status
      );

      Status = PeiServicesSetBootMode (BOOT_WITH_DEFAULT_SETTINGS);
      
      mde_3_edkii_vga_sprintf(6, "c-%x",
        Status
      );

      DEBUG ((DEBUG_INFO, "BootMode: Boot with default settings\n"));
      // ASSERT_EFI_ERROR (Status);
    } else {
      
      mde_3_edkii_vga_sprintf(6, "d-%x",
        Status
      );

      Status = PeiServicesSetBootMode (BOOT_ASSUMING_NO_CONFIGURATION_CHANGES);
      
      mde_3_edkii_vga_sprintf(6, "e-%x",
        Status
      );

      DEBUG ((DEBUG_INFO, "BootMode: Boot boot assuming no configuration changes\n"));
      // ASSERT_EFI_ERROR (Status);
    }
  }

  
  mde_3_edkii_vga_sprintf(7, "a-%x",
    0
  );

  //
  // Create guid hob for Tcg Physical Presence Interface
  //
  Status = ParseTPMPPIInfo (&PhysicalPresenceInfo);
  
  mde_3_edkii_vga_sprintf(7, "b-%x-%x-%x-%x",
    Status,
    PhysicalPresenceInfo.PpiAddress,
    PhysicalPresenceInfo.PpiVersion,
    PhysicalPresenceInfo.TpmVersion
  );

  if (!EFI_ERROR (Status)) {
    NewPhysicalPresenceInfo = BuildGuidHob (&gEfiTcgPhysicalPresenceInfoHobGuid, sizeof (TCG_PHYSICAL_PRESENCE_INFO));
    
    mde_3_edkii_vga_sprintf(8, "a-%x-%x-%x-%x",
      Status,
      NewPhysicalPresenceInfo->PpiAddress,
      NewPhysicalPresenceInfo->PpiVersion,
      NewPhysicalPresenceInfo->TpmVersion
    );
    
    // ASSERT (NewPhysicalPresenceInfo != NULL);
    CopyMem (NewPhysicalPresenceInfo, &PhysicalPresenceInfo, sizeof (TCG_PHYSICAL_PRESENCE_INFO));
    
    mde_3_edkii_vga_sprintf(8, "b-%x-%x-%x-%x",
      Status,
      NewPhysicalPresenceInfo->PpiAddress,
      NewPhysicalPresenceInfo->PpiVersion,
      NewPhysicalPresenceInfo->TpmVersion
    );
    DEBUG ((DEBUG_INFO, "Created Tcg Physical Presence info hob\n"));
  }

  
  mde_3_edkii_vga_sprintf(9, "a-%x",
    0
  );

  //
  // Create guid hob for system tables like acpi table and smbios table
  //
  Status = ParseSystemTable(&SysTableInfo);
  
  mde_3_edkii_vga_sprintf(9, "a-%x-%x-%x-%x",
    Status,
    SysTableInfo.AcpiTableBase,
    SysTableInfo.AcpiTableSize,
    SysTableInfo.SmbiosTableBase,
    SysTableInfo.SmbiosTableSize
  );

  // ASSERT_EFI_ERROR (Status);
  if (!EFI_ERROR (Status)) {
    NewSysTableInfo = BuildGuidHob (&gUefiSystemTableInfoGuid, sizeof (SYSTEM_TABLE_INFO));
    
    mde_3_edkii_vga_sprintf(10, "a-%x-%x-%x-%x-%x",
      Status,
      NewSysTableInfo->AcpiTableBase,
      NewSysTableInfo->AcpiTableSize,
      NewSysTableInfo->SmbiosTableBase,
      NewSysTableInfo->SmbiosTableSize
    );
    
    // ASSERT (NewSysTableInfo != NULL);
    CopyMem (NewSysTableInfo, &SysTableInfo, sizeof (SYSTEM_TABLE_INFO));
    
    mde_3_edkii_vga_sprintf(10, "b-%x-%x-%x-%x-%x",
      Status,
      NewSysTableInfo->AcpiTableBase,
      NewSysTableInfo->AcpiTableSize,
      NewSysTableInfo->SmbiosTableBase,
      NewSysTableInfo->SmbiosTableSize
    );
    
    DEBUG ((DEBUG_INFO, "Detected Acpi Table at 0x%lx, length 0x%x\n", SysTableInfo.AcpiTableBase, SysTableInfo.AcpiTableSize));
    DEBUG ((DEBUG_INFO, "Detected Smbios Table at 0x%lx, length 0x%x\n", SysTableInfo.SmbiosTableBase, SysTableInfo.SmbiosTableSize));
  }

  
  mde_3_edkii_vga_sprintf(11, "a-%x",
    0
  );
  
  //
  // Create guid hob for acpi board information
  //
  Status = ParseAcpiInfo (SysTableInfo.AcpiTableBase, &AcpiBoardInfo);
  
  mde_3_edkii_vga_sprintf(11, "b-%x-%x-%x-%x-%x-%x-%x-%x",
    Status,
    AcpiBoardInfo.PcieBaseAddress,
    AcpiBoardInfo.PcieBaseSize,
    AcpiBoardInfo.PmCtrlRegBase,
    AcpiBoardInfo.PmEvtBase,
    AcpiBoardInfo.PmGpeEnBase,
    AcpiBoardInfo.PmTimerRegBase,
    AcpiBoardInfo.ResetRegAddress,
    AcpiBoardInfo.ResetValue
  );
  
  // ASSERT_EFI_ERROR (Status);
  if (!EFI_ERROR (Status)) {
    
    mde_3_edkii_vga_sprintf(12, "a-%x",
      0
    );

    NewAcpiBoardInfo = BuildGuidHob (&gUefiAcpiBoardInfoGuid, sizeof (ACPI_BOARD_INFO));
    
    mde_3_edkii_vga_sprintf(12, "b-%x-%x-%x-%x-%x-%x-%x-%x",
      NewAcpiBoardInfo,
      NewAcpiBoardInfo->PcieBaseAddress,
      NewAcpiBoardInfo->PcieBaseSize,
      NewAcpiBoardInfo->PmCtrlRegBase,
      NewAcpiBoardInfo->PmEvtBase,
      NewAcpiBoardInfo->PmGpeEnBase,
      NewAcpiBoardInfo->PmTimerRegBase,
      NewAcpiBoardInfo->ResetRegAddress,
      NewAcpiBoardInfo->ResetValue
    );
    // ASSERT (NewAcpiBoardInfo != NULL);
    CopyMem (NewAcpiBoardInfo, &AcpiBoardInfo, sizeof (ACPI_BOARD_INFO));
    
    mde_3_edkii_vga_sprintf(12, "c-%x-%x-%x-%x-%x-%x-%x-%x",
      NewAcpiBoardInfo,
      NewAcpiBoardInfo->PcieBaseAddress,
      NewAcpiBoardInfo->PcieBaseSize,
      NewAcpiBoardInfo->PmCtrlRegBase,
      NewAcpiBoardInfo->PmEvtBase,
      NewAcpiBoardInfo->PmGpeEnBase,
      NewAcpiBoardInfo->PmTimerRegBase,
      NewAcpiBoardInfo->ResetRegAddress,
      NewAcpiBoardInfo->ResetValue
    );
    DEBUG ((DEBUG_INFO, "Create acpi board info guid hob\n"));
  }

  
  mde_3_edkii_vga_sprintf(13, "a-%x",
    0
  );
  // Build SEC Performance Data Hob
  Status =   ParseTimestampTable(&Performance);
  if (!EFI_ERROR (Status)) {
    mde_3_edkii_vga_sprintf(13, "b-%x",
      0
    );
    BuildGuidDataHob (&gEfiFirmwarePerformanceGuid, &Performance, sizeof (Performance));
    
    mde_3_edkii_vga_sprintf(13, "c-%x",
      Performance.ResetEnd
    );
  } else {
    
    mde_3_edkii_vga_sprintf(13, "d-%x",
      0
    );
    DEBUG ((DEBUG_ERROR, "Error when parsing timestamp info, Status = %r\n", Status));
  }

  
  mde_3_edkii_vga_sprintf(14, "a-%x",
    0
  );
  //
  // Parse platform specific information.
  //
  Status = ParsePlatformInfo ();
  
  mde_3_edkii_vga_sprintf(14, "b-%x",
    Status
  );
  if (EFI_ERROR (Status)) {
    DEBUG ((DEBUG_ERROR, "Error when parsing platform info, Status = %r\n", Status));
    return Status;
  }

  //
  // Import update capsules, if there are any.
  //
  
  mde_3_edkii_vga_sprintf(15, "a-%x",
    0
  );
  Status = ParseCapsules (BuildCvHob);
  
  mde_3_edkii_vga_sprintf(15, "b-%x",
    Status
  );
  if (EFI_ERROR (Status)) {
    DEBUG ((DEBUG_ERROR, "Error when importing update capsules, Status = %r\n", Status));
    return Status;
  }

  
  mde_3_edkii_vga_sprintf(15, "c-%x",
    Status
  );
  if (GetFirstHob (EFI_HOB_TYPE_UEFI_CAPSULE) != NULL || ParseIsDiskCapsulesBoot ()) {
    
    mde_3_edkii_vga_sprintf(15, "d-%x",
      Status
    );
    if (GetFirstHob (EFI_HOB_TYPE_UEFI_CAPSULE) != NULL) {
      
      mde_3_edkii_vga_sprintf(15, "e-%x",
        Status
      );
      DEBUG ((DEBUG_INFO, "BootMode: Flash update (for in-RAM capsule(s))\n"));
    } else {
      
      mde_3_edkii_vga_sprintf(15, "f-%x",
        Status
      );
      DEBUG ((DEBUG_INFO, "BootMode: Flash update (for on-disk capsule(s))\n"));
    }

    mde_3_edkii_vga_sprintf(16, "a-%x",
      0
    );
    Status = PeiServicesSetBootMode (BOOT_ON_FLASH_UPDATE);
    

    mde_3_edkii_vga_sprintf(16, "b-%x",
      Status
    );
    // ASSERT_EFI_ERROR (Status);
  }

  
  mde_3_edkii_vga_sprintf(17, "a-%x",
    0
  );
  //
  // Mask off all legacy 8259 interrupt sources
  //
  IoWrite8 (LEGACY_8259_MASK_REGISTER_MASTER, 0xFF);
  IoWrite8 (LEGACY_8259_MASK_REGISTER_SLAVE,  0xFF);

  mde_3_edkii_vga_sprintf(17, "b-%x",
    0
  );

  //
  // Parse coreboot's log.
  //
  Status = ParseAndPublishTPMLog ();
  
  mde_3_edkii_vga_sprintf(17, "c-%x",
    Status
  );
  if (EFI_ERROR (Status)) {
    DEBUG ((DEBUG_ERROR, "Error when parsing platform info, Status = %r\n", Status));
    return Status;
  }

  return EFI_SUCCESS;
}

